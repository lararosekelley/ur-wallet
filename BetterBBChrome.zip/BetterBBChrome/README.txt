README: BetterBB

This is a Chrome Extension desgined to provide you with quick and easy access to common information on BlackBoard.

How to Install and Run
	github.com/tylucaskelley/BetterBB
	Download ZIP
	Chrome --> Settings --> Extensions --> Developer Mode --> Load Unpacked Extension --> Find the BetterBB folder